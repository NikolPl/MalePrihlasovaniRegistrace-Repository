package cz.czechitas.webapp;

import java.util.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

@Controller
public class HlavniController {


    @RequestMapping("/")
    public ModelAndView zobrazPexeso() {
        ModelAndView pexeso = new ModelAndView("index");

        List<String> obrazkyList = new ArrayList<String>();
        obrazkyList.add("images/obr0.JPG");
        obrazkyList.add("images/obr1.JPG");
        obrazkyList.add("images/obr2.JPG");
        obrazkyList.add("images/obr3.JPG");
        obrazkyList.add("images/obr4.JPG");
        obrazkyList.add("images/obr5.JPG");
        obrazkyList.add("images/obr6.JPG");
        obrazkyList.add("images/obr7.JPG");
        Collections.shuffle(obrazkyList);
        List<String> zamichane = new ArrayList<String>();
        for (String obr : obrazkyList){
            zamichane.add(obr);
        }
        pexeso.addObject("obrazkyZamichane", zamichane);

        Collections.shuffle(obrazkyList);
        pexeso.addObject("zamichaneObrazky",obrazkyList);


        List<Hrac> listHracu = new ArrayList<Hrac>();
        listHracu.add(new Hrac("Božidara","Bohyňová",30,50));
        listHracu.add(new Hrac("Oliver", "Východní",2,5));
        listHracu.add(new Hrac("Karel","Jeliman",30,50));
        listHracu.add(new Hrac("Vladěna", "Severní",2,5));
        listHracu.add(new Hrac("Lucián","Kdovíkdo   ",30,50));
        listHracu.add(new Hrac("Rusoslava", "Rudá",2,5));

        pexeso.addObject("preneseniHraci",listHracu);
        return pexeso;


    }

}
